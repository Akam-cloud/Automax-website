# Execute the following in MySQL
SOURCE AutomaxCreate.sql;
SOURCE AutomaxInsert.sql;
SOURCE AutomaxQueries.sql

# View reports
SOURCE AutomaxQueries.sql;
